#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Bode plot implementation: plot frequency and phase response in dB according to a logarithmic frequency scale
"""

from __future__ import unicode_literals, print_function, absolute_import, division
try:
    from future_builtins import ascii, hex, filter, map, oct, zip
except ImportError:
    pass

import numpy as np
import matplotlib.pyplot as plt
from numpy import pi, log10

EPS = np.spacing(0)     # to prevent div/0 or log(0)


def bode_plot(dft_arr, _fs=1, phase=False, wholefft=False):
    """Plot logarithmic scale for frequency response signals"""

    if wholefft is False:
        _nfft = 2*len(dft_arr)
    else:
        _nfft = len(dft_arr)

    _k_arr = np.arange(_nfft//2) / (_nfft//2) * _fs/2
    x_max = _fs / 2

    # Create good-looking log ticks according to FFT length
    if _fs == 1:
        tck_tpl = (0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5)
        tck_lst = [tck for tck in tck_tpl if tck <= x_max]
        xlabel_txt = "Normalized frequency (fs = 1)"
    else:
        tck_tpl = (20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000)
        tck_lst = [tck for tck in tck_tpl if tck <= x_max]
        xlabel_txt = "Frequency in (Hz)"

    if phase is False:
        num_plots = 1
    else:
        num_plots = 2

    fig1, ax_arr = plt.subplots(num_plots, squeeze=False)  # squeeze=False for 1 graph, still an array
    ax_arr = ax_arr[:, 0]                                  # 2d-array > 1d-array

    ax_arr[0].plot(_k_arr, 20*log10(np.abs(dft_arr)+EPS)[:_nfft//2])

    ax_arr[0].set_ylabel('Amplitude (dB)')
    ax_arr[0].set_title('Frequency response')

    for ax in ax_arr:
        ax.set_xscale('log')
        ax.set_xlim((tck_tpl[0], x_max))
        ax.set_xticks(tck_lst)
        ax.xaxis.set_major_formatter(plt.FormatStrFormatter('%g'))
        ax.set_ylim((-120, 20))
        ax.grid(True, which='major', color='0.7', linestyle='-')
        ax.grid(True, which='minor', color='0.9', linestyle='-')

    if num_plots == 1:
        ax_arr[0].set_xlabel(xlabel_txt)
    else:
        ax_arr[1].plot(_k_arr, np.angle(dft_arr)[:int(_nfft//2)]*180/pi)
        ax_arr[1].set_ylim((-180, 180))
        ax_arr[1].set_yticks(np.arange(-180, 180+1, 45))
        ax_arr[1].set_xlabel(xlabel_txt)
        ax_arr[1].set_ylabel('Phase (deg)')